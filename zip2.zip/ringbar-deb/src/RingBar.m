// RingBar - circular status bar widgets (time, date, weather, battery, connectivity) for Nyxian's
// home screen. Runs inside SpringBoard through ElleKit / TweakInject. Original implementation.
//
// Notes: Wi-Fi / Bluetooth / Airplane cannot be switched from here (Nyxian's sandbox has no access to
// those system controls), so the connectivity ring shows the current state; tapping a ring shows an
// alternate readout. Weather comes from Open-Meteo (no API key).
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <netinet/in.h>
#import <dlfcn.h>
#import <objc/runtime.h>
#import <notify.h>

#define kDomain   @"com.ganbi.ringbar"
#define kNotify   "com.ganbi.ringbar/prefs"
#define kLockName @"ringbar-4.lock"
#define kMarkName @"ringbar-4.reported"

enum { kNone = 0, kTime, kDate, kWeather, kBattery, kConn };

// ---------- settings ----------
static BOOL gEnabled = YES, g24h = NO, gF = NO, gHideStock = YES, gHaptics = YES;
static NSInteger gSlot[4] = { kTime, kDate, kWeather, kBattery };
static NSInteger gAccent = 0;
static double gSize = 26;
static NSString *gLat = @"", *gLon = @"";
static NSString *gSig = @"";
static NSString *gPrefSrc = @"(defaults, no prefs file found)";

// ---------- log / status ----------
static NSMutableString *LOGS;
static void lg(NSString *f, ...) NS_FORMAT_FUNCTION(1, 2);
static void lg(NSString *f, ...) {
    va_list a; va_start(a, f);
    NSString *s = [[NSString alloc] initWithFormat:f arguments:a];
    va_end(a);
    if (!LOGS) LOGS = [NSMutableString new];
    [LOGS appendFormat:@"%@\n", s];
}

static NSString *docsDir(void) { return [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]; }

static void writeAll(NSString *name, NSString *s) {
    NSMutableArray *paths = [NSMutableArray arrayWithObjects:
        [docsDir() stringByAppendingPathComponent:name],
        [NSTemporaryDirectory() stringByAppendingPathComponent:name], nil];
    NSString *hd = NSHomeDirectory();
    NSRange r = [hd rangeOfString:@"/Library/Boot/"];
    if (r.location != NSNotFound) [paths addObject:[[[hd substringToIndex:r.location] stringByAppendingString:@"/Documents/"] stringByAppendingString:name]];
    for (NSString *p in paths) [s writeToFile:p atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

// ---------- reading Tweak Settings (PreferenceLoader) values ----------
static NSArray *prefPaths(void) {
    NSString *fn = [kDomain stringByAppendingString:@".plist"];
    NSMutableArray *a = [NSMutableArray array];
    [a addObject:[[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences"] stringByAppendingPathComponent:fn]];
    for (NSString *base in @[NSBundle.mainBundle.executablePath ?: @"", NSHomeDirectory()]) {
        NSRange r = [base rangeOfString:@"/Library/Boot/"];
        if (r.location == NSNotFound) continue;
        NSString *boot = [base substringToIndex:r.location + 14];
        NSString *root = [boot stringByAppendingString:@"org.emexlabs.procursus.jailed.root/Documents/rootfs"];
        [a addObject:[NSString stringWithFormat:@"%@/var/mobile/Library/Preferences/%@", root, fn]];
        [a addObject:[NSString stringWithFormat:@"%@/opt/procursus/var/mobile/Library/Preferences/%@", root, fn]];
    }
    return a;
}

static NSDictionary *readPrefs(void) {
    NSDictionary *best = nil; NSDate *bestD = nil;
    for (NSString *p in prefPaths()) {
        NSDictionary *at = [NSFileManager.defaultManager attributesOfItemAtPath:p error:nil];
        if (!at) continue;
        NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:p];
        if (!d) continue;
        NSDate *m = at.fileModificationDate;
        if (!bestD || [m compare:bestD] == NSOrderedDescending) { best = d; bestD = m; gPrefSrc = p; }
    }
    if (!best) {
        NSDictionary *d = [[[NSUserDefaults alloc] initWithSuiteName:kDomain] dictionaryRepresentation];
        if (d[@"enabled"] || d[@"l1"] || d[@"size"] || d[@"accent"]) { best = d; gPrefSrc = @"NSUserDefaults"; }
    }
    return best;
}

static BOOL boolFrom(id v, BOOL def) { return v ? [v boolValue] : def; }
static double numFrom(id v, double def) { return (v && [v respondsToSelector:@selector(doubleValue)]) ? [v doubleValue] : def; }
static double clampd(double v, double lo, double hi) { return MAX(lo, MIN(hi, v)); }
static NSString *strFrom(id v) {
    if (!v) return @"";
    NSString *s = [[NSString stringWithFormat:@"%@", v] stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    return s ?: @"";
}

// returns YES if effective settings changed
static BOOL loadPrefs(void) {
    NSDictionary *d = readPrefs();
    BOOL en = boolFrom(d[@"enabled"], YES);
    NSInteger l1 = (NSInteger)clampd(numFrom(d[@"l1"], kTime), 0, 5);
    NSInteger l2 = (NSInteger)clampd(numFrom(d[@"l2"], kDate), 0, 5);
    NSInteger r1 = (NSInteger)clampd(numFrom(d[@"r1"], kWeather), 0, 5);
    NSInteger r2 = (NSInteger)clampd(numFrom(d[@"r2"], kBattery), 0, 5);
    double size = clampd(numFrom(d[@"size"], 26), 20, 34);
    NSInteger accent = (NSInteger)clampd(numFrom(d[@"accent"], 0), 0, 6);
    BOOL h24 = boolFrom(d[@"h24"], NO);
    BOOL f = boolFrom(d[@"fahrenheit"], NO);
    NSString *lat = strFrom(d[@"lat"]), *lon = strFrom(d[@"lon"]);
    BOOL hide = boolFrom(d[@"hideStock"], YES);
    BOOL hap = boolFrom(d[@"haptics"], YES);
    NSString *sig = [NSString stringWithFormat:@"%d|%ld%ld%ld%ld|%.1f|%ld|%d|%d|%@|%@|%d|%d", en, (long)l1, (long)l2, (long)r1, (long)r2,
                     size, (long)accent, h24, f, lat, lon, hide, hap];
    if ([sig isEqualToString:gSig]) return NO;
    gSig = sig;
    gEnabled = en; gSlot[0] = l1; gSlot[1] = l2; gSlot[2] = r1; gSlot[3] = r2;
    gSize = size; gAccent = accent; g24h = h24; gF = f; gLat = lat; gLon = lon; gHideStock = hide; gHaptics = hap;

    lg(@"prefs: enabled=%d slots=%ld,%ld,%ld,%ld size=%.0f accent=%ld 24h=%d F=%d lat='%@' lon='%@' hideStock=%d src=%@",
       en, (long)l1, (long)l2, (long)r1, (long)r2, size, (long)accent, h24, f, lat, lon, hide, gPrefSrc);
    return YES;
}

// ---------- live data ----------
static BOOL gWxOK = NO, gWxDay = YES;
static double gWxTemp = 0, gWxWind = 0;
static int gWxCode = 0;
static NSString *gWxStatus = @"not fetched yet";
static NSString *gGeoLat, *gGeoLon;
static NSString *gUsedLat, *gUsedLon;

static NSDateFormatter *fmtFor(NSString *f) {
    static NSMutableDictionary *cache;
    if (!cache) cache = [NSMutableDictionary new];
    NSDateFormatter *d = cache[f];
    if (!d) { d = [NSDateFormatter new]; d.dateFormat = f; cache[f] = d; }
    return d;
}

static int netState(void) {   // 0 offline, 1 wifi, 2 cellular
    static SCNetworkReachabilityRef ref;
    if (!ref) {
        struct sockaddr_in z; memset(&z, 0, sizeof z); z.sin_len = sizeof z; z.sin_family = AF_INET;
        ref = SCNetworkReachabilityCreateWithAddress(NULL, (const struct sockaddr *)&z);
    }
    SCNetworkReachabilityFlags fl = 0;
    if (!ref || !SCNetworkReachabilityGetFlags(ref, &fl)) return 0;
    if (!(fl & kSCNetworkReachabilityFlagsReachable)) return 0;
    if (fl & kSCNetworkReachabilityFlagsIsWWAN) return 2;
    return 1;
}

// ---------- battery: IOKit AppleSmartBattery (live) with UIDevice as fallback ----------
static BOOL ioBattery(double *pct, BOOL *ext, BOOL *chg) {
    static BOOL tried;
    static CFMutableDictionaryRef (*fMatch)(const char *);
    static uint32_t (*fGet)(uint32_t, CFDictionaryRef);
    static CFTypeRef (*fProp)(uint32_t, CFStringRef, CFAllocatorRef, uint32_t);
    static int (*fRel)(uint32_t);
    if (!tried) {
        tried = YES;
        void *h = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_LAZY);
        if (h) {
            fMatch = (CFMutableDictionaryRef (*)(const char *))dlsym(h, "IOServiceMatching");
            fGet   = (uint32_t (*)(uint32_t, CFDictionaryRef))dlsym(h, "IOServiceGetMatchingService");
            fProp  = (CFTypeRef (*)(uint32_t, CFStringRef, CFAllocatorRef, uint32_t))dlsym(h, "IORegistryEntryCreateCFProperty");
            fRel   = (int (*)(uint32_t))dlsym(h, "IOObjectRelease");
        }
    }
    if (!fMatch || !fGet || !fProp) return NO;
    uint32_t svc = fGet(0, fMatch("AppleSmartBattery"));
    if (!svc) return NO;
    CFTypeRef cur = fProp(svc, CFSTR("CurrentCapacity"), NULL, 0);
    CFTypeRef mx  = fProp(svc, CFSTR("MaxCapacity"), NULL, 0);
    CFTypeRef ex  = fProp(svc, CFSTR("ExternalConnected"), NULL, 0);
    CFTypeRef ic  = fProp(svc, CFSTR("IsCharging"), NULL, 0);
    BOOL ok = NO;
    if (cur && CFGetTypeID(cur) == CFNumberGetTypeID()) {
        double c = 0, m = 100;
        CFNumberGetValue((CFNumberRef)cur, kCFNumberDoubleType, &c);
        if (mx && CFGetTypeID(mx) == CFNumberGetTypeID()) CFNumberGetValue((CFNumberRef)mx, kCFNumberDoubleType, &m);
        double p = m > 0 ? c * 100.0 / m : c;
        if (p >= 0 && p <= 100.5) { *pct = p; ok = YES; }
    }
    *ext = (ex && CFGetTypeID(ex) == CFBooleanGetTypeID()) ? CFBooleanGetValue((CFBooleanRef)ex) : NO;
    *chg = (ic && CFGetTypeID(ic) == CFBooleanGetTypeID()) ? CFBooleanGetValue((CFBooleanRef)ic) : NO;
    if (cur) CFRelease(cur);
    if (mx) CFRelease(mx);
    if (ex) CFRelease(ex);
    if (ic) CFRelease(ic);
    if (fRel) fRel(svc);
    return ok;
}

static void batteryInfo(float *lvl, BOOL *chg, BOOL *full, const char **src) {
    UIDevice *dv = UIDevice.currentDevice;
    if (!dv.batteryMonitoringEnabled) dv.batteryMonitoringEnabled = YES;
    float l = dv.batteryLevel;
    BOOL c = dv.batteryState == UIDeviceBatteryStateCharging || dv.batteryState == UIDeviceBatteryStateFull;
    BOOL f = dv.batteryState == UIDeviceBatteryStateFull;
    const char *sr = "UIDevice";
    double p = 0; BOOL ext = NO, ich = NO;
    if (ioBattery(&p, &ext, &ich)) {
        l = (float)(p / 100.0);
        c = ext || ich;
        f = ext && p >= 99.5;
        sr = "IOKit";
    }
    *lvl = l; *chg = c; *full = f; *src = sr;
}

static NSString *wxSymbol(int c, BOOL day) {
    if (c == 0) return day ? @"sun.max.fill" : @"moon.stars.fill";
    if (c <= 2) return day ? @"cloud.sun.fill" : @"cloud.moon.fill";
    if (c == 3) return @"cloud.fill";
    if (c == 45 || c == 48) return @"cloud.fog.fill";
    if (c >= 51 && c <= 57) return @"cloud.drizzle.fill";
    if (c >= 61 && c <= 67) return @"cloud.rain.fill";
    if ((c >= 71 && c <= 77) || (c >= 85 && c <= 86)) return @"cloud.snow.fill";
    if (c >= 80 && c <= 82) return @"cloud.heavyrain.fill";
    if (c >= 95) return @"cloud.bolt.rain.fill";
    return @"cloud.fill";
}

@class RBBar;
static RBBar *gBar;
static void refreshAllRings(void);

static void doFetch(NSString *lat, NSString *lon) {
    gUsedLat = lat; gUsedLon = lon;
    NSString *u = [NSString stringWithFormat:@"https://api.open-meteo.com/v1/forecast?latitude=%@&longitude=%@&current_weather=true", lat, lon];
    NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:u] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:15];
    [[NSURLSession.sharedSession dataTaskWithRequest:rq completionHandler:^(NSData *data, NSURLResponse *resp, NSError *err) {
        NSDictionary *j = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
        NSDictionary *cw = [j isKindOfClass:NSDictionary.class] ? j[@"current_weather"] : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            if ([cw isKindOfClass:NSDictionary.class] && cw[@"temperature"]) {
                gWxTemp = [cw[@"temperature"] doubleValue];
                gWxWind = [cw[@"windspeed"] doubleValue];
                gWxCode = [cw[@"weathercode"] intValue];
                gWxDay = cw[@"is_day"] ? [cw[@"is_day"] boolValue] : YES;
                gWxOK = YES;
                gWxStatus = [NSString stringWithFormat:@"ok (%@,%@) %.1fC code %d", lat, lon, gWxTemp, gWxCode];
            } else {
                gWxStatus = [NSString stringWithFormat:@"fetch failed: %@", err.localizedDescription ?: @"bad response"];
            }
            refreshAllRings();
        });
    }] resume];
}

static void fetchWeather(void) {
    if (gLat.length && gLon.length && (gLat.doubleValue != 0 || gLon.doubleValue != 0)) { doFetch(gLat, gLon); return; }
    if (gGeoLat && gGeoLon) { doFetch(gGeoLat, gGeoLon); return; }
    NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://ipwho.is/"] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:15];
    [[NSURLSession.sharedSession dataTaskWithRequest:rq completionHandler:^(NSData *data, NSURLResponse *resp, NSError *err) {
        NSDictionary *j = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
        id la = [j isKindOfClass:NSDictionary.class] ? j[@"latitude"] : nil;
        id lo = [j isKindOfClass:NSDictionary.class] ? j[@"longitude"] : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            if (la && lo) {
                gGeoLat = [NSString stringWithFormat:@"%.4f", [la doubleValue]];
                gGeoLon = [NSString stringWithFormat:@"%.4f", [lo doubleValue]];
                doFetch(gGeoLat, gGeoLon);
            } else {
                gWxStatus = [NSString stringWithFormat:@"auto location failed: %@", err.localizedDescription ?: @"bad response"];
                refreshAllRings();
            }
        });
    }] resume];
}

// ---------- colors ----------
static UIColor *accentColor(NSInteger idx) {
    switch (idx) {
        case 1: return [UIColor colorWithWhite:1 alpha:1];
        case 2: return [UIColor colorWithRed:0.35 green:0.65 blue:1.00 alpha:1];
        case 3: return [UIColor colorWithRed:0.30 green:0.85 blue:0.50 alpha:1];
        case 4: return [UIColor colorWithRed:1.00 green:0.65 blue:0.25 alpha:1];
        case 5: return [UIColor colorWithRed:1.00 green:0.45 blue:0.70 alpha:1];
        case 6: return [UIColor colorWithRed:0.70 green:0.50 blue:1.00 alpha:1];
        default: return nil;
    }
}

// ---------- a single ring ----------
@interface RBRing : UIView
@property (nonatomic, assign) NSInteger kind;
@property (nonatomic, assign) BOOL alt;
@property (nonatomic, strong) CAShapeLayer *track, *arc;
@property (nonatomic, strong) UILabel *l1, *l2, *l3;
@property (nonatomic, strong) UIImageView *icon;
@property (nonatomic, strong) NSArray *dots;
- (void)refresh;
@end

@implementation RBRing

static UILabel *mkLabel(UIView *parent) {
    UILabel *l = [UILabel new];
    l.textAlignment = NSTextAlignmentCenter;
    l.textColor = UIColor.whiteColor;
    l.adjustsFontSizeToFitWidth = YES;
    l.minimumScaleFactor = 0.6;
    l.userInteractionEnabled = NO;
    [parent addSubview:l];
    return l;
}

- (instancetype)initWithFrame:(CGRect)f {
    if ((self = [super initWithFrame:f])) {
        self.userInteractionEnabled = YES;
        _track = [CAShapeLayer layer];
        _track.fillColor = nil;
        _track.strokeColor = [UIColor colorWithWhite:1 alpha:0.22].CGColor;
        [self.layer addSublayer:_track];
        _arc = [CAShapeLayer layer];
        _arc.fillColor = nil;
        _arc.lineCap = kCALineCapRound;
        _arc.strokeEnd = 0;
        [self.layer addSublayer:_arc];
        _l1 = mkLabel(self); _l2 = mkLabel(self); _l3 = mkLabel(self);
        _icon = [UIImageView new];
        _icon.contentMode = UIViewContentModeScaleAspectFit;
        _icon.tintColor = UIColor.whiteColor;
        [self addSubview:_icon];
        NSMutableArray *d = [NSMutableArray array];
        for (int i = 0; i < 3; i++) {
            CAShapeLayer *s = [CAShapeLayer layer];
            [self.layer addSublayer:s];
            [d addObject:s];
        }
        _dots = d;
    }
    return self;
}

- (void)setKind:(NSInteger)k { if (_kind != k) { _kind = k; [self setNeedsLayout]; } }

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat D = self.bounds.size.width, s = D / 26.0, lw = 2.4 * s;
    UIBezierPath *p = [UIBezierPath bezierPathWithArcCenter:CGPointMake(D / 2, D / 2) radius:(D - lw) / 2
                                                 startAngle:0.75 * M_PI endAngle:2.25 * M_PI clockwise:YES];
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    self.track.frame = self.bounds; self.arc.frame = self.bounds;
    self.track.path = p.CGPath; self.arc.path = p.CGPath;
    self.track.lineWidth = lw; self.arc.lineWidth = lw;
    [CATransaction commit];

    UIFont *(^B)(CGFloat) = ^UIFont *(CGFloat sz) { return [UIFont systemFontOfSize:sz * s weight:UIFontWeightBold]; };
    CGFloat w = D - 2 * lw - 1;
    CGFloat cy = D / 2;
    switch (self.kind) {
        case kTime:
            self.l1.font = B(8.5); self.l2.font = B(8.5); self.l3.font = B(4.8);
            self.l1.frame = CGRectMake(lw, cy - 11 * s, w, 9 * s);
            self.l2.frame = CGRectMake(lw, cy - 2.5 * s, w, 9 * s);
            self.l3.frame = CGRectMake(lw, cy + 6 * s, w, 5.5 * s);
            break;
        case kDate:
            self.l1.font = B(9.5); self.l2.font = B(6.5); self.l3.font = B(5.5);
            self.l1.frame = CGRectMake(lw, cy - 10.5 * s, w, 10 * s);
            self.l2.frame = CGRectMake(lw, cy - 0.5 * s, w, 7.5 * s);
            self.l3.frame = CGRectMake(lw, cy + 6 * s, w, 6 * s);
            break;
        case kWeather:
            self.l1.font = B(10.5);
            self.l1.frame = CGRectMake(lw, cy - 9 * s, w, 11 * s);
            self.icon.frame = CGRectMake(D / 2 - 5 * s, cy + 3 * s, 10 * s, 8 * s);
            break;
        case kBattery:
            self.l1.font = B(10.5);
            self.l1.frame = CGRectMake(lw, cy - 9 * s, w, 11 * s);
            self.icon.frame = CGRectMake(D / 2 - 4 * s, cy + 3 * s, 8 * s, 8 * s);
            break;
        case kConn: {
            self.icon.frame = CGRectMake(D / 2 - 6 * s, cy - 8 * s, 12 * s, 11 * s);
            self.l1.font = B(5.5);
            self.l1.frame = CGRectMake(lw, cy - 6 * s, w, 7 * s);
            CGFloat dd = 2.6 * s;
            for (int i = 0; i < 3; i++) {
                CAShapeLayer *sl = self.dots[i];
                sl.path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, dd, dd)].CGPath;
                sl.frame = CGRectMake(D / 2 - 1.5 * dd - 1 * s + i * (dd + 1 * s), cy + 7 * s, dd, dd);
            }
            break;
        }
        default: break;
    }
    [self refresh];
}

- (UIImage *)symbol:(NSString *)name size:(CGFloat)pt {
    UIImageSymbolConfiguration *c = [UIImageSymbolConfiguration configurationWithPointSize:pt weight:UIImageSymbolWeightBold];
    UIImage *im = [UIImage systemImageNamed:name withConfiguration:c];
    return [im imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
}

- (void)refresh {
    CGFloat D = self.bounds.size.width, s = D / 26.0;
    UIColor *accent = accentColor(gAccent);
    UIColor *arcColor = accent ?: UIColor.whiteColor;
    double progress = 0;
    BOOL showL1 = NO, showL2 = NO, showL3 = NO, showIcon = NO, showDots = NO;
    NSDate *now = [NSDate date];

    switch (self.kind) {
        case kTime: {
            showL1 = showL2 = YES; showL3 = !g24h && !self.alt;
            if (self.alt) { self.l1.text = [fmtFor(@"ss") stringFromDate:now]; self.l2.text = @"sec"; }
            else {
                self.l1.text = [fmtFor(g24h ? @"HH" : @"h") stringFromDate:now];
                self.l2.text = [fmtFor(@"mm") stringFromDate:now];
                self.l3.text = [fmtFor(@"a") stringFromDate:now];
            }
            progress = [[fmtFor(@"ss") stringFromDate:now] doubleValue] / 60.0;
            if (!accent) arcColor = [UIColor colorWithRed:0.55 green:0.80 blue:1.0 alpha:1];
            break;
        }
        case kDate: {
            showL1 = showL2 = YES; showL3 = !self.alt;
            if (self.alt) { self.l1.text = [fmtFor(@"EEE") stringFromDate:now]; self.l2.text = [fmtFor(@"MMM") stringFromDate:now]; }
            else {
                self.l1.text = [fmtFor(@"dd") stringFromDate:now];
                self.l2.text = [fmtFor(@"MMM") stringFromDate:now];
                self.l3.text = [fmtFor(@"yy") stringFromDate:now];
            }
            NSCalendar *cal = NSCalendar.currentCalendar;
            NSInteger day = [cal component:NSCalendarUnitDay fromDate:now];
            NSInteger len = [cal rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:now].length;
            progress = len ? (double)day / len : 0;
            if (!accent) arcColor = [UIColor colorWithRed:1.0 green:0.65 blue:0.30 alpha:1];
            break;
        }
        case kWeather: {
            showL1 = YES; showIcon = gWxOK;
            {
                CGFloat lw0 = 2.4 * s, w0 = D - 2 * lw0 - 1;
                self.l1.frame = gWxOK ? CGRectMake(lw0, D / 2 - 9.5 * s, w0, 11 * s) : CGRectMake(lw0, D / 2 - 5.5 * s, w0, 11 * s);
                self.icon.frame = CGRectMake(D / 2 - 5 * s, D / 2 + 3 * s, 10 * s, 8 * s);
            }
            if (!gWxOK) { self.l1.text = @"--"; }
            else if (self.alt) {
                self.l1.text = [NSString stringWithFormat:@"%ld", lround(gF ? gWxWind * 0.621371 : gWxWind)];
                self.icon.image = [self symbol:@"wind" size:8 * s];
            } else {
                double t = gF ? gWxTemp * 9.0 / 5.0 + 32 : gWxTemp;
                self.l1.text = [NSString stringWithFormat:@"%ld°", lround(t)];
                self.icon.image = [self symbol:wxSymbol(gWxCode, gWxDay) size:8 * s];
            }
            progress = gWxOK ? clampd((gWxTemp + 10.0) / 50.0, 0.04, 1) : 0;
            if (!accent) arcColor = [UIColor colorWithRed:0.45 green:0.85 blue:1.0 alpha:1];
            break;
        }
        case kBattery: {
            float lvl = -1; BOOL chg = NO, full = NO; const char *src = "";
            batteryInfo(&lvl, &chg, &full, &src);
            BOOL low = NSProcessInfo.processInfo.isLowPowerModeEnabled;
            CGFloat lw0 = 2.4 * s, w0 = D - 2 * lw0 - 1;
            // number is centered; it only moves up while charging, to make room for the bolt
            self.l1.frame = chg ? CGRectMake(lw0, D / 2 - 9.5 * s, w0, 11 * s) : CGRectMake(lw0, D / 2 - 5.5 * s, w0, 11 * s);
            self.icon.frame = CGRectMake(D / 2 - 4 * s, D / 2 + 3 * s, 8 * s, 8 * s);
            showL1 = YES;
            if (self.alt) {
                self.l1.text = chg ? (full ? @"Full" : @"Chg") : (low ? @"Low" : @"Bat");
            } else {
                self.l1.text = lvl >= 0 ? [NSString stringWithFormat:@"%d", (int)lround(lvl * 100)] : @"--";
            }
            showIcon = chg;
            if (chg) self.icon.image = [self symbol:@"bolt.fill" size:7 * s];
            progress = lvl >= 0 ? lvl : 0;
            UIColor *auto_ = chg ? [UIColor colorWithRed:0.30 green:0.90 blue:0.40 alpha:1]
                                 : (low ? [UIColor colorWithRed:1.0 green:0.85 blue:0.20 alpha:1] : UIColor.whiteColor);
            arcColor = accent ?: auto_;
            if (!chg && lvl >= 0 && lvl <= 0.2) arcColor = [UIColor colorWithRed:1.0 green:0.30 blue:0.30 alpha:1];
            self.icon.tintColor = arcColor;
            break;
        }
        case kConn: {
            int n = netState();
            showIcon = YES; showDots = YES; showL1 = self.alt;
            if (self.alt) { self.l1.text = n == 1 ? @"Wi-Fi" : (n == 2 ? @"Cell" : @"Off"); showIcon = NO; }
            else {
                NSString *nm = n == 1 ? @"wifi" : (n == 2 ? @"cellularbars" : @"wifi.slash");
                UIImage *im = [self symbol:nm size:10 * s];
                self.icon.image = im ?: [self symbol:@"antenna.radiowaves.left.and.right" size:10 * s];
            }
            progress = n ? 1 : 0.04;
            UIColor *col = n == 1 ? [UIColor colorWithRed:0.35 green:0.65 blue:1.0 alpha:1]
                         : (n == 2 ? [UIColor colorWithRed:0.30 green:0.85 blue:0.50 alpha:1] : [UIColor colorWithRed:1.0 green:0.35 blue:0.35 alpha:1]);
            arcColor = accent ?: col;
            NSArray *dc = @[[UIColor colorWithRed:0.35 green:0.65 blue:1.0 alpha:1], [UIColor colorWithRed:0.30 green:0.85 blue:0.50 alpha:1], [UIColor colorWithRed:1.0 green:0.35 blue:0.35 alpha:1]];
            int active = n == 1 ? 0 : (n == 2 ? 1 : 2);
            [CATransaction begin];
            [CATransaction setDisableActions:YES];
            for (int i = 0; i < 3; i++) {
                CAShapeLayer *sl = self.dots[i];
                sl.fillColor = ((UIColor *)dc[i]).CGColor;
                sl.opacity = i == active ? 1.0 : 0.25;
            }
            [CATransaction commit];
            break;
        }
        default: break;
    }

    self.l1.hidden = !showL1; self.l2.hidden = !showL2; self.l3.hidden = !showL3;
    self.icon.hidden = !showIcon;
    if (self.kind != kBattery) self.icon.tintColor = UIColor.whiteColor;
    for (CAShapeLayer *sl in self.dots) sl.hidden = !showDots;

    BOOL smooth = self.kind == kTime && !self.alt;
    [CATransaction begin];
    if (smooth) { [CATransaction setAnimationDuration:1.0]; [CATransaction setAnimationTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]]; }
    else [CATransaction setDisableActions:YES];
    self.arc.strokeColor = arcColor.CGColor;
    self.arc.strokeEnd = (CGFloat)clampd(progress, 0.001, 1.0);
    [CATransaction commit];
}

@end

// ---------- the bar (container of the 4 rings) ----------
@interface RBBar : UIView
@property (nonatomic, strong) NSArray *rings;
@property (nonatomic, weak) UIView *homeView;
@property (nonatomic, assign) CGFloat topInset;
- (void)relayout;
- (void)refreshAll;
@end

@implementation RBBar

- (instancetype)initWithFrame:(CGRect)f {
    if ((self = [super initWithFrame:f])) {
        self.backgroundColor = nil;
        NSMutableArray *a = [NSMutableArray array];
        for (int i = 0; i < 4; i++) {
            RBRing *r = [[RBRing alloc] initWithFrame:CGRectMake(0, 0, 26, 26)];
            UITapGestureRecognizer *t = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapped:)];
            [r addGestureRecognizer:t];
            [self addSubview:r];
            [a addObject:r];
        }
        _rings = a;
    }
    return self;
}

- (BOOL)pointInside:(CGPoint)p withEvent:(UIEvent *)e {
    for (RBRing *r in self.rings)
        if (!r.hidden && CGRectContainsPoint(CGRectInset(r.frame, -6, -8), p)) return YES;
    return NO;
}

- (void)tapped:(UITapGestureRecognizer *)g {
    RBRing *r = (RBRing *)g.view;
    if (gHaptics) { UIImpactFeedbackGenerator *fb = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight]; [fb impactOccurred]; }
    if (r.kind == kWeather) fetchWeather();
    r.alt = YES;
    [r refresh];
    [UIView animateWithDuration:0.12 animations:^{ r.transform = CGAffineTransformMakeScale(1.18, 1.18); }
                     completion:^(BOOL f) { [UIView animateWithDuration:0.18 animations:^{ r.transform = CGAffineTransformIdentity; }]; }];
    __weak RBRing *wr = r;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ RBRing *x = wr; if (x) { x.alt = NO; [x refresh]; } });
}

- (void)relayout {
    CGFloat W = self.superview.bounds.size.width;
    CGFloat Hh = self.superview.bounds.size.height;
    CGFloat top = self.topInset > 0 ? self.topInset : 48;
    CGFloat D = (CGFloat)gSize, gap = 6, margin = 20;
    CGFloat cy = MAX(top / 2.0, D / 2.0 + 2);
    self.frame = CGRectMake(0, 0, W, MAX(top, D + 8));

    NSMutableArray *left = [NSMutableArray array], *right = [NSMutableArray array];
    for (int i = 0; i < 4; i++) {
        RBRing *r = self.rings[i];
        NSInteger k = gEnabled ? gSlot[i] : kNone;
        r.kind = k;
        r.hidden = (k == kNone);
        r.bounds = CGRectMake(0, 0, D, D);
        if (k == kNone) continue;
        if (i < 2) [left addObject:r]; else [right addObject:r];
    }
    CGFloat x = margin;
    for (RBRing *r in left) { r.center = CGPointMake(x + D / 2, cy); x += D + gap; }
    x = W - margin;
    for (RBRing *r in [right reverseObjectEnumerator]) { r.center = CGPointMake(x - D / 2, cy); x -= D + gap; }
    self.hidden = !gEnabled || (W > Hh);   // hide in landscape
    for (RBRing *r in self.rings) { [r setNeedsLayout]; }
}

- (void)refreshAll { for (RBRing *r in self.rings) if (!r.hidden) [r refresh]; }

@end

static void refreshAllRings(void) { [gBar refreshAll]; }

// ---------- attaching to the home screen ----------
static __weak UIViewController *gHomeVC;
static BOOL gAttached = NO, gReported = NO;

static void walkVC(UIViewController *vc, int d, NSMutableArray *homes) {
    if (!vc || d > 14) return;
    if ([NSStringFromClass(vc.class) rangeOfString:@"HomeScreen"].location != NSNotFound) [homes addObject:vc];
    for (UIViewController *c in vc.childViewControllers) walkVC(c, d + 1, homes);
    UIViewController *p = vc.presentedViewController;
    if (p && p.presentingViewController == vc) walkVC(p, d + 1, homes);
}

static NSArray *allWindows(void) {
    NSMutableArray *a = [NSMutableArray array];
    UIApplication *app = [UIApplication sharedApplication];
    for (UIScene *s in app.connectedScenes)
        if ([s isKindOfClass:UIWindowScene.class]) [a addObjectsFromArray:((UIWindowScene *)s).windows];
    if (!a.count && app.windows) [a addObjectsFromArray:app.windows];
    return a;
}

static void enforceStockBar(void) {
    UIViewController *vc = gHomeVC;
    if (!vc) return;
    Ivar iv = class_getInstanceVariable(vc.class, "_systemStatusBarHost");
    if (!iv) return;
    UIView *host = object_getIvar(vc, iv);
    if (![host isKindOfClass:UIView.class]) return;
    CGFloat want = (gEnabled && gHideStock) ? 0.0 : 1.0;
    if (fabs(host.alpha - want) > 0.01) host.alpha = want;
}

// ---------- overlay window: lives in Nyxian's SpringBoard, above the home screen AND above app windows ----------
@interface RBWindow : UIWindow
@end
@implementation RBWindow
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e {
    UIView *v = [super hitTest:p withEvent:e];
    if (!v || v == self || v == self.rootViewController.view) return nil;   // let everything else pass through
    return v;
}
@end

static RBWindow *gWin;

static UIWindowScene *findScene(void) {
    UIWindowScene *best = nil;
    for (UIWindow *w in allWindows()) {
        if (!w.windowScene) continue;
        if ([NSStringFromClass(w.class) isEqualToString:@"NXSBOverlayWindow"]) return w.windowScene;
        if (!best) best = w.windowScene;
    }
    return best;
}

static void ensureWindow(void) {
    if (!gBar) return;
    if (!gWin) {
        UIWindowScene *sc = findScene();
        RBWindow *w = sc ? [[RBWindow alloc] initWithWindowScene:sc] : [[RBWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
        w.windowLevel = 99999;       // above apps; just under FloatingHome's window (100000)
        w.backgroundColor = nil;
        w.opaque = NO;
        UIViewController *vc = [UIViewController new];
        vc.view.backgroundColor = nil;
        w.rootViewController = vc;
        gWin = w;
        lg(@"overlay window created (scene found: %d)", sc != nil);
    }
    UIView *root = gWin.rootViewController.view;
    if (gBar.superview != root) { [root addSubview:gBar]; [gBar relayout]; }
    if (gWin.hidden) gWin.hidden = NO;
    [root bringSubviewToFront:gBar];
}

static void report(NSString *why, UIView *host) {
    if (gReported) return;
    gReported = YES;
    lg(@"RingBar 1.1.0 status: %@", why);
    lg(@"weather: %@ (used lat/lon: %@ , %@)", gWxStatus, gUsedLat ?: @"-", gUsedLon ?: @"-");
    {
        float lv = -1; BOOL c = NO, f = NO; const char *src = "";
        batteryInfo(&lv, &c, &f, &src);
        double ip = -1; BOOL e = NO, ic = NO;
        BOOL iok = ioBattery(&ip, &e, &ic);
        lg(@"battery used: %.2f (source %s), charging=%d | IOKit ok=%d pct=%.1f ext=%d | UIDevice level=%.2f state=%ld | net=%d",
           lv, src, c, iok, ip, e, UIDevice.currentDevice.batteryLevel, (long)UIDevice.currentDevice.batteryState, netState());
    }
    lg(@"overlay window: %@ level=%.0f", gWin ? NSStringFromCGRect(gWin.frame) : @"nil", gWin.windowLevel);
    if (host) lg(@"home bounds=%@ safeTop=%.0f bar=%@", NSStringFromCGRect(host.bounds), host.safeAreaInsets.top, gBar ? NSStringFromCGRect(gBar.frame) : @"nil");
    lg(@"prefs source: %@", gPrefSrc);
    NSString *out = [LOGS copy];
    writeAll(@"ringbar-status.txt", out);
    NSString *mark = [docsDir() stringByAppendingPathComponent:kMarkName];
    if (![NSFileManager.defaultManager fileExistsAtPath:mark]) {
        [@"1" writeToFile:mark atomically:YES encoding:NSUTF8StringEncoding error:nil];
        UIPasteboard.generalPasteboard.string = out;
    }
}

static void tick(void) {
    [gBar refreshAll];
    enforceStockBar();
    ensureWindow();
    static int n30;
    if (++n30 % 30 == 0) {   // nudge UIDevice battery monitoring (fallback path)
        UIDevice *dv = UIDevice.currentDevice;
        dv.batteryMonitoringEnabled = NO;
        dv.batteryMonitoringEnabled = YES;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ tick(); });
}

static void findHome(int n) {
    if (gAttached) return;
    UIViewController *h = nil;
    for (UIWindow *w in allWindows()) {
        NSMutableArray *a = [NSMutableArray array];
        walkVC(w.rootViewController, 1, a);
        if (a.count) { h = a.firstObject; break; }
    }
    if (h && h.isViewLoaded) {
        gAttached = YES;
        gHomeVC = h;
        UIDevice.currentDevice.batteryMonitoringEnabled = YES;
        gBar = [[RBBar alloc] initWithFrame:CGRectMake(0, 0, h.view.bounds.size.width, 48)];
        gBar.homeView = h.view;
        gBar.topInset = h.view.safeAreaInsets.top;
        ensureWindow();
        [gBar relayout];
        [gBar refreshAll];
        fetchWeather();
        tick();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 20 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ fetchWeather(); });
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 6 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ report(@"rings attached", h.view); });
        return;
    }
    if (n < 60) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ findHome(n + 1); });
    else report(@"home screen NOT found after 60s", nil);
}

// ---------- live settings ----------
static NSString *gLastLoc = @"";
static void onPrefsMaybeChanged(void) {
    if (!loadPrefs()) return;
    [gBar relayout];
    [gBar refreshAll];
    enforceStockBar();
    NSString *loc = [NSString stringWithFormat:@"%@|%@", gLat, gLon];
    if (![loc isEqualToString:gLastLoc]) { gLastLoc = loc; fetchWeather(); }
}

static void pollPrefs(void) {
    onPrefsMaybeChanged();
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ pollPrefs(); });
}

__attribute__((constructor)) static void init(void) {
    NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
    if (![bid isEqualToString:@"com.apple.springboard"] && ![NSProcessInfo.processInfo.processName isEqualToString:@"SpringBoard"]) return;

    // crash guard: if a previous launch died within the first seconds, stay disabled
    NSString *lock = [docsDir() stringByAppendingPathComponent:kLockName];
    if ([NSFileManager.defaultManager fileExistsAtPath:lock]) return;
    [@"1" writeToFile:lock atomically:YES encoding:NSUTF8StringEncoding error:nil];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 25 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [NSFileManager.defaultManager removeItemAtPath:lock error:nil];
    });

    loadPrefs();
    gLastLoc = [NSString stringWithFormat:@"%@|%@", gLat, gLon];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 4 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        findHome(0);
        int token = 0;
        notify_register_dispatch(kNotify, &token, dispatch_get_main_queue(), ^(int t) { onPrefsMaybeChanged(); });
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ pollPrefs(); });
    });
}
